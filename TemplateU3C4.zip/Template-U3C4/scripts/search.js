function storeSearchterm(search,searchele) {

   async function searchitem(){
       let res =  await fetch(`https://shrouded-earth-23381.herokuapp.com/api/search/?q=${search}`);

       let data = await res.json();
      
       console.log(data);
       data.map(elem =>{
        let container = document.createElement('div')
          container.setAttribute('id','box')
  
          let image_div= document.createElement('div');
          image_div.setAttribute('id','image')
  
          let image = document.createElement('img')
          image.src = elem.urlToImage;
          
          image_div.append(image)
          let titlediv = document.createElement('div')
  
          let title = document.createElement('h4')
          title.textContent=elem.title
          
          let description = document.createElement('p')
          description.textContent=elem.description;

           titlediv.append(head,des);
          container.append(image_div,titlediv);
  
          searchele.append(container);
      })
   }
   
   searchitem();
   
}

export default storeSearchterm