async function apiCall(url) {


    //add api call logic here
   let res = await fetch(url)

   let data = await res.json();

   return data;

}


function appendArticles(articles, main) {

    //add append logic here
    articles.map((elem,index) =>{
        let container = document.createElement('div')
        container.setAttribute('id','box')

        box.addEventListener('click',()=>{
            localStorage.setItem('article',JSON.stringify(articles[index]))
            window.location.href='news.html'
        })

        let image= document.createElement('div');
        image.setAttribute('id','image')

        let image = document.createElement('img')
        image.src = elem.urlToImage;
        
        image_div.append(image)
      

        let title = document.createElement('h4')
        title.textContent=elem.title
       
         title_div.append(title)
        container.append(image,title)

        main.append(container)


    })
 

}

export { apiCall, appendArticles }