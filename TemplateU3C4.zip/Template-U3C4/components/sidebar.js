function sidebar() {


    // return your html component here
    //Make sure to give input search box id as ""
    return `  
    <h3>Menu</h3>
    <input type="text" placeholder="Search article" id="searchbar">
    <h3>Login</h3>
    <h3>Signup</h3>
    <h3>articles</h3>`
}
export default sidebar